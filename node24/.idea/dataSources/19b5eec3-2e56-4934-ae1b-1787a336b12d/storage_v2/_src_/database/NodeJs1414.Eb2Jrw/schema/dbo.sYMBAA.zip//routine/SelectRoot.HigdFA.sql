CREATE PROCEDURE SelectRoot(@level int)    
AS   
BEGIN  
   select hid.ToString(), * from Lab5 where hid.GetLevel() = @level;
END;
go

