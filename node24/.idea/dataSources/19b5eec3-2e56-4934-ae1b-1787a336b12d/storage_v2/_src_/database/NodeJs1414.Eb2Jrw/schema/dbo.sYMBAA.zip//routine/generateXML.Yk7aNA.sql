create procedure generateXML
as
declare @x XML
set @x = (Select vac.Id [Id], Company [Company], can.Position [Position],
				FName[FName], SName[LName], Age, Sex, Salary,GETDATE() [Date] 
from VACANCY vac join CANDIDATE can on vac.Id = can.Job
FOR XML AUTO);
SELECT @x
go

