CREATE PROCEDURE AddDocherRoot(@UserId int,@UserName nvarchar(50))   
AS   
BEGIN  
declare @Id hierarchyid
declare @phId hierarchyid
select @phId = (SELECT hid FROM Lab5 WHERE UserId = @UserId);

select @Id = MAX(hid) from Lab5 where hid.GetAncestor(1) = @phId

insert into Lab5 values( @phId.GetDescendant(@id, null),@UserId,@UserName);
END;
go

